'use client'

import React from 'react'
import Link from 'next/link'
import { ChevronLeft, ChevronRight, Clapperboard } from 'lucide-react'

import { MediaType } from '@/types/media'
import { ItemType } from '@/types/movie-result'
import { cn, itemRedirect } from '@/lib/utils'
import { Card } from '@/components/card'
import { SeeAllLink } from '@/components/see-all-link'

interface ListProps {
  title: string
  items: MediaType[]
  itemType?: ItemType
}

// Fraction of the visible rail width one arrow-press scrolls. ~90% keeps a
// sliver of the previous card on screen as an anchor (Netflix-style paging).
const PAGE_FRACTION = 0.9
// Past this many pixels of pointer travel a press counts as a drag, not a
// click — so a drag-to-scroll never accidentally opens the card underneath.
const DRAG_THRESHOLD = 8

/**
 * Horizontal poster rail. Replaces the old Splide carousel: the track is now a
 * native overflow-x scroll container with CSS scroll-snap, so scrolling runs on
 * the compositor (GPU) with zero per-frame JS — touch swipe and trackpad work
 * for free and stay buttery on mobile. The chrome (heading hover, arrow reveal)
 * is plain CSS — nothing in this rail runs framer any more. Desktop keeps
 * click-drag and hover-reveal arrows for parity with the previous UX.
 */
export const List = ({ title, items, itemType = 'movie' }: ListProps) => {
  const safeItems = Array.isArray(items) ? items : []
  const railRef = React.useRef<HTMLDivElement>(null)
  const [canLeft, setCanLeft] = React.useState(false)
  const [canRight, setCanRight] = React.useState(false)

  // Pointer drag-to-scroll (mouse only — touch already scrolls natively). Kept
  // in a ref so the listeners never need to re-bind and don't trigger renders.
  const drag = React.useRef({
    active: false,
    moved: false,
    startX: 0,
    startScroll: 0,
  })

  const syncArrows = React.useCallback(() => {
    const el = railRef.current
    if (!el) return
    // 1px slack absorbs sub-pixel rounding at the extremes.
    setCanLeft(el.scrollLeft > 1)
    setCanRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 1)
  }, [])

  React.useEffect(() => {
    syncArrows()
    const el = railRef.current
    if (!el) return
    const onResize = () => syncArrows()
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [syncArrows, safeItems])

  const scrollByPage = React.useCallback((direction: 1 | -1) => {
    const el = railRef.current
    if (!el) return
    el.scrollBy({
      left: direction * el.clientWidth * PAGE_FRACTION,
      behavior: 'smooth',
    })
  }, [])

  const onPointerDown = React.useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      if (e.pointerType !== 'mouse') return
      const el = railRef.current
      if (!el) return
      drag.current = {
        active: true,
        moved: false,
        startX: e.clientX,
        startScroll: el.scrollLeft,
      }
    },
    []
  )

  const onPointerMove = React.useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const state = drag.current
      if (!state.active) return
      const el = railRef.current
      if (!el) return
      const delta = e.clientX - state.startX
      if (!state.moved && Math.abs(delta) > DRAG_THRESHOLD) {
        state.moved = true
        el.setPointerCapture(e.pointerId)
      }
      if (state.moved) el.scrollLeft = state.startScroll - delta
    },
    []
  )

  const endDrag = React.useCallback(() => {
    drag.current.active = false
  }, [])

  // If the press turned into a drag, swallow the click so the card link under
  // the cursor doesn't fire. Runs in the capture phase, before the link's own
  // handler. `moved` is reset here so the next genuine click passes through.
  const onClickCapture = React.useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (drag.current.moved) {
        e.preventDefault()
        e.stopPropagation()
        drag.current.moved = false
      }
    },
    []
  )

  return (
    // Self-contained horizontal gutter so the rail renders IDENTICALLY wherever
    // it's used — homepage rows, movie/series detail "Similar"/"Recommended".
    // Callers must NOT add their own horizontal padding (the detail pages used to
    // wrap this in a narrow `container`, which made the row a different width than
    // home and clipped the scroll region).
    <nav className="cv-auto px-5 py-6 sm:px-8 sm:py-8 lg:px-12 lg:py-10 xl:px-16 2xl:px-20">
      {/* Heading row: title left, See all right. The chip is ALWAYS visible —
          the old "Explore All" was a hover reveal, which on touch screens (most
          of the audience) meant the row had no way forward at all. The accent
          bar keeps its small hover flourish; the destination is no longer a
          secret handshake. */}
      <div className="group/heading mb-4 flex items-center justify-between gap-4">
        <Link
          href={itemRedirect(itemType)}
          // Prefetched: every heading on the page points at one of the same two
          // section routes (/movies, /tv-shows), so the router dedupes them into
          // two prerendered-asset fetches for the whole homepage — not the
          // per-card storm the card links below still have to avoid.
          className="flex w-fit min-w-0 items-center gap-2"
        >
          <h2 className="flex min-w-0 items-center gap-2.5 text-2xl font-bold tracking-tight transition-colors duration-200 ease-in group-hover/heading:text-cyan-200">
            <span
              aria-hidden
              className="h-5 w-[3px] shrink-0 origin-center rounded-full bg-gradient-to-b from-cyan-300 to-cyan-500 opacity-85 shadow-[0_0_8px_rgba(103,232,249,0.5)] transition-[transform,opacity] duration-300 ease-[cubic-bezier(0.34,1.4,0.64,1)] group-hover/heading:scale-y-[1.35] group-hover/heading:opacity-100 motion-reduce:transition-none"
            />
            <span className="truncate">{title}</span>
          </h2>
        </Link>
        <SeeAllLink href={itemRedirect(itemType)} label={title} />
      </div>

      {safeItems.length === 0 && (
        <div
          role="status"
          className="text-muted-foreground border-border/60 flex items-center gap-2 rounded-lg border border-dashed px-4 py-6 text-sm"
        >
          <Clapperboard className="size-4 shrink-0 opacity-70" />
          Nothing to show here yet — check back soon.
        </div>
      )}

      {safeItems.length > 0 && (
        <div className="group/rail relative">
          {/* Scroll track: native, GPU-driven, snap-aligned. `overflow-x-auto`
              forces `overflow-y: clip` AND clips horizontally at the scroll
              extremes, so the hover lift (translateY -10 + scale 1.05) needs
              breathing room on ALL four sides or the edge cards get cut — the
              first card's left grows ~6px past scrollLeft:0 and the top grows
              ~19px above the track. `-my-6 py-6` gives 24px vertical clip-room;
              `-mx-4 px-4` gives 16px horizontal room the same way (equal negative
              margin bleeds the track into the nav gutter — 16px < the 20px
              min gutter so it never causes page overflow — while the padding
              holds the content in place, so the row's layout position is
              unchanged: no jump when StaticRail swaps to this List). `scroll-pl-4`
              keeps snap-start aligning the first card to the heading, not to the
              bled-out padding edge. Scrollbar hidden via .no-scrollbar. */}
          <div
            ref={railRef}
            onScroll={syncArrows}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={endDrag}
            onPointerLeave={endDrag}
            onClickCapture={onClickCapture}
            // No `scroll-smooth` here: it makes every `scrollLeft` write during a
            // pointer-drag animate toward its target, so rapid drag updates fight
            // the smoothing and the rail feels stuck / unswipeable on desktop.
            // Arrow paging still animates via scrollBy({ behavior: 'smooth' }).
            className="no-scrollbar -mx-4 -my-6 flex snap-x snap-mandatory scroll-pl-4 gap-6 overflow-x-auto px-4 py-6"
          >
            {safeItems.map((item) => (
              // Responsive width matching SliderHorizontalListLoader so the
              // Suspense skeleton → real card swap doesn't jump the rail (the
              // card poster is now w-full of this box, not a fixed 250px).
              <div
                key={item.id}
                className="w-[160px] shrink-0 snap-start sm:w-[190px] lg:w-[230px] 2xl:w-[250px]"
              >
                <Card item={item} itemType={itemType} />
              </div>
            ))}
          </div>

          {/* Hover-revealed glass arrows (lg+ only; touch uses swipe). Each fades
              out at its end of the track. Mirrors the hero carousel's chrome. */}
          <RailArrow
            direction="left"
            visible={canLeft}
            onClick={() => scrollByPage(-1)}
          />
          <RailArrow
            direction="right"
            visible={canRight}
            onClick={() => scrollByPage(1)}
          />
        </div>
      )}
    </nav>
  )
}

interface RailArrowProps {
  direction: 'left' | 'right'
  visible: boolean
  onClick: () => void
}

const RailArrow = ({ direction, visible, onClick }: RailArrowProps) => {
  const isLeft = direction === 'left'
  const Icon = isLeft ? ChevronLeft : ChevronRight
  return (
    // Pure-CSS chrome: Tailwind v4 drives `translate`/`scale` as independent CSS
    // properties, so the hover scale never disturbs the -translate-y-1/2
    // centering (and there's no per-arrow motion node to mount).
    <button
      type="button"
      aria-label={isLeft ? 'Scroll left' : 'Scroll right'}
      onClick={onClick}
      tabIndex={visible ? 0 : -1}
      className={cn(
        'absolute top-1/2 z-20 hidden size-12 -translate-y-1/2 scale-100 place-items-center rounded-full border border-white/15 bg-[rgba(10,12,20,0.62)] text-white shadow-[0_10px_30px_rgba(0,0,0,0.5),inset_0_1px_0_rgba(255,255,255,0.12)] backdrop-blur-md backdrop-saturate-150 lg:grid',
        'opacity-0 transition-[opacity,scale,background,border-color] duration-300 ease-out',
        'hover:scale-[1.08] hover:border-cyan-300/55 hover:bg-[rgba(20,24,36,0.82)] active:scale-95',
        'focus-visible:border-cyan-300/70 focus-visible:opacity-100 focus-visible:outline-none',
        'group-focus-within/rail:opacity-100 group-hover/rail:opacity-100',
        isLeft ? 'left-2' : 'right-2',
        !visible && 'pointer-events-none !opacity-0'
      )}
    >
      <Icon className="size-[1.1rem] drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]" />
    </button>
  )
}
