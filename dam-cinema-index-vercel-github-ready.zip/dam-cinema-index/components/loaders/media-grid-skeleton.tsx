import React from 'react'

import { SkeletonContainer } from '@/components/ui/skeleton'

interface MediaGridSkeletonProps {
  count?: number
}

export const MediaGridSkeleton = ({ count = 20 }: MediaGridSkeletonProps) => {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
      {Array.from({ length: count }).map((_, i) => (
        <SkeletonContainer key={i}>
          <div className="space-y-3">
            <div className="bg-muted/80 aspect-[2/3] rounded-lg" />
            <div className="bg-muted h-3 w-11/12 rounded-lg" />
            <div className="bg-muted/70 h-3 w-8/12 rounded-lg" />
          </div>
        </SkeletonContainer>
      ))}
    </div>
  )
}
