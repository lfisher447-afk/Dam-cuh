'use client'

import React from 'react'
import { Bookmark, BookmarkCheck } from 'lucide-react'
import { toast } from 'sonner'

import { MovieDetails } from '@/types/movie-details'
import { SeriesDetails } from '@/types/series-details'
import { getMediaTitle } from '@/lib/media'
import { cn } from '@/lib/utils'
import { useMounted } from '@/hooks/use-mounted'
import { useWatchlist } from '@/hooks/use-watchlist'
import { Button } from '@/components/ui/button'
import {
  heroActionButtonBase,
  heroActionButtonIdle,
  heroActionButtonSaved,
} from '@/components/ui/hero-action-button'

interface SaveButtonProps {
  media: MovieDetails & SeriesDetails
  className?: string
}

// Memoised: `media` is a server payload object and `className` a literal, so
// both are stable per call site. The watchlist state this reads comes from a
// hook, which memo does not block — a save still repaints the button.
export const SaveButton = React.memo(function SaveButton({
  media,
  className,
}: SaveButtonProps) {
  const { isSaved, toggle } = useWatchlist()
  const isMounted = useMounted()

  // Until mounted, the saved state is unknown on the server (localStorage is
  // client-only), so we render the neutral "Save" state on both the server and
  // the first client render to stay hydration-safe (React #418).
  const saved = isMounted && isSaved(media.id)

  const handleClick = () => {
    const title = getMediaTitle(media)
    // `saved` is the pre-toggle state, so it tells us which way we're flipping.
    if (saved) {
      toggle(media)
      toast(`Removed “${title}” from your watchlist`)
    } else {
      toggle(media)
      toast.success(`Saved “${title}” to your watchlist`)
    }
  }

  return (
    <Button
      type="button"
      variant="ghost"
      size="lg"
      aria-pressed={saved}
      aria-label={saved ? 'Remove from watchlist' : 'Save to watchlist'}
      onClick={handleClick}
      className={cn(
        heroActionButtonBase,
        saved ? heroActionButtonSaved : heroActionButtonIdle,
        className
      )}
    >
      {saved ? (
        <BookmarkCheck className="size-5 text-cyan-300 drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]" />
      ) : (
        <Bookmark className="size-5 drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]" />
      )}
      <span className="hidden sm:inline">{saved ? 'Saved' : 'Save'}</span>
    </Button>
  )
})
